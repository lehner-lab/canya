import sys
import argparse
from . import utils
from . import models

def parse_inputs():
    parser = argparse.ArgumentParser(prog='CANYA', description='Command line interface for the CANYA package')
    parser.add_argument(
        '--input', default='example.fa', help='Input sequences, either a FASTA or a text file with\
        two *tab-delimited* columns with *no* header or column-names. Columns contain a \
        sequence idenity (arbirtrary) as well as the amino acid sequence.'
    )
    parser.add_argument(
        '--output', default='example_out', help='Name/directory of the output txt file. If run in\
        the default mode, CANYA will output a single, tab-delimited file named after this prefix\
        with two columns: (1) with the sequence identity (FASTA header or corresponding column of\
        the input text file) (2) The CANYA nucleation score.\
        If run in motif mode, a folder will be created that contains a file per sequence, where rows\
        are named with the specific cluster, columns after the sequence position, and each entry contains\
        the activation energy of the cluster at that position. Activation energies can be summarized with\
        the --act argument.'
    )
    parser.add_argument(
        '--mode', default='default', help='Mode to run CANYA. Default mode outputs a single\
        tab-delimited text file containing sequence identities and a CANYA score. \'motif\' \
        mode will dump a file per sequence containing the activation energies per clusterXposition.\
        Activation energies within a cluster can be summarized according to the --act argument.',
        choices=["default", "motif"]
    )
    parser.add_argument(
        '--act', default='max', help='Function by which to summarize filter activations for a given\
        cluster. Default is \'max\', other options are \'mean\' and \'min\'. Explicitly, this function\
        collapses the activation energies across all filters comprising a cluster for a given position.',
        choices=["max","mean","min"]
    )

    # Parse all command line arguments
    args = parser.parse_args(args)
    return args

def main()
    args=parse_inputs()
    print(args.mode)
    print("parsed things!)

if __name__ == '__main__':
    main()