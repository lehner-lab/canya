CANYA a neural net to predict nucleation propensity
