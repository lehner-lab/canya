from setuptools import setup, find_packages

setup(
    name="canya",
    version="0.0.1",
    description="CANYA a hybrid neural-network to predict nucleation propensities",
    author='Mike Thompson',
    author_email='mjthompson at ucla dot edu',
    packages=find_packages(),
    classifiers=[
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.6",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3 :: Only",
    ],
    # Do not install tensorflow here, because might want to use tensorflow or
    # tensorflow-cpu.
    install_requires=[
        "numpy",
        "pandas<=1.3.3"    ],
    python_requires=">=3.6, <4",
)