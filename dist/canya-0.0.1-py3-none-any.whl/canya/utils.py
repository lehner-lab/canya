import tensorflow as tf
from tensorflow import keras

import pandas as pd
import numpy as np

def dynamic_padding(inp, min_size,
                   consval=-1,post=True):
    pad_size = min_size - tf.shape(inp)[0]
    paddings = [[0, pad_size], [0, 0]] # assign here, during graph execution
    if not post:
        paddings = [[pad_size, 0], [0, 0]]
    return tf.pad(inp, paddings,constant_values=consval)

aas="ACDEFGHIKLMNPQRSTVWY"
def str_to_vector(str, template):
    #   return [ei_vec(template.index(nt),len(template)) for nt in str]
    mapping = dict(zip(template, range(len(template))))
    seq = [mapping[i] for i in str]
    return np.eye(len(template))[seq]

def seq_to_vector(seq):
    return str_to_vector(seq, aas)
    


